from flask import Blueprint, jsonify, request, url_for
from flask_login import current_user
from web.models import db, Chat, User
from sqlalchemy import or_
from  web.extensions import socketio, limiter
from web.apis.errors import bad_request, response

chat_api = Blueprint('chat_api', __name__)

# // General/(*) chat/conversations
import uuid, json
# Assuming that socketio is your SocketIO instance

class ConnectionManager:
    def __init__(self):
        self.active_connections = {}

    def connect(self, socket_id):
        self.active_connections[socket_id] = True

    def disconnect(self, socket_id):
        if socket_id in self.active_connections:
            del self.active_connections[socket_id]

    def is_connected(self, socket_id):
        return socket_id in self.active_connections

    def send_chat_to(self, socket_id, message):
        if self.is_connected(socket_id):
            socketio.emit('chat', message, room=socket_id)

    def notify(self, socket_id, message):
        #if self.is_connected(socket_id):
        socketio.emit('response', message, room=socket_id)

connection_manager = ConnectionManager()

payload = {
    'to' : 0,
    'fro' : 0,
    'text' : '',
    'sticker' : '',
    'media' : '',
    'client': False,
    "type": "", #[connect, discount, typing, chat(custom)]
    #"id": user_id
    }

@socketio.on('connect', namespace='/chat')
@limiter.limit("1 per second")
#@socketio.on('connect')
def handle_connect():
    user_id = request.sid
    payload['fro'] = user_id
    payload['type'] = 'connect'
    
    connection_manager.connect(user_id)

    print(payload)

    connection_manager.send_chat_to(user_id, json.dumps(payload))

@socketio.on('disconnect', namespace='/chat')
def handle_disconnect():
    user_id = request.sid
    connection_manager.disconnect(user_id)

@socketio.on('typing', namespace='/chat')
def handle_typing(data):

    fro = request.sid

    if connection_manager.is_connected(data.to):
        """ create event to inform clients connected """
        payload = {"type": "typing", "fro": fro, "text": data.txt}
        connection_manager.send_chat_to(data.to, json.dumps(payload))
    else:
        """pass"""
        print('recipient not connected for', fro)
        # Handle the case when the recipient is not connected
        # You can notify the sender or take other appropriate actions
    print('data is:', data)

@socketio.on('save-chat', namespace='/chat')
def save(data):
    
    #pls validations here first
    if not (['fro','to'] and ('text' or 'sticker' or 'media') ) in data:
        #return bad_request('Can Not Send Blank Chats')
        data['error'] = True
        return connection_manager.notify(response.to, json.dumps(bad_request('Invalid payload')))

    if not User.user_exists(data.fro) and not User.user_exists(data.to):
        #return bad_request('Invalid User Id(s)')
        data['error'] = True
        return connection_manager.notify(data.fro, json.dumps(bad_request('Invalid user-ids')))
    
    chat = Chat()
    chat.from_dict(data, new_chat=True)
    db.session.add(chat)
    db.session.commit()
    response = chat.to_dict()
    #return response

    #if .to is online, tell f.from they're online
    if connection_manager.is_connected(data.to or request.sid):
        """update payload if .to is online/connected"""
        response['online'] = True 
    response['success'] = True
    return connection_manager.notify(response.to, json.dumps(response))

@socketio.on('fetch-chat', namespace='/chat')
#@token_auth.login_required
def fetch(data):
    if current_user.is_authenticated and not (data.id == current_user.id):
        data = bad_request('nah, it\'s a blank chat')
        data['error'] = True
        return connection_manager.notify(data.fro, json.dumps(data))
    chat = Chat.query.filter(or_(Chat.to == data.id, Chat.fro == data.id)).order_by(Chat.updated.desc())
    page = request.args.get('page', 1, type=int)
    per_page = min(request.args.get('per_page', 10, type=int), 100)
    data = Chat.to_collection_dict(chat, page, per_page, 'chat_api.get_chat', id=id)
    #return jsonify(data)
    data['success'] = True
    connection_manager.notify(data.fro, json.dumps(data))

@socketio.on('remove-chat', namespace='chat')
def remove(data):  # Use 'id' as the parameter name
    chat = Chat.query.get(data.id)  # Replace 'chat_id' with 'id'
    if chat:
        if not (chat.fro == current_user.id or chat.to == current_user.id):
            return bad_request(message="Invalid Conversation Request")
        if chat.fro == current_user.id or request.sid:
            chat.fro_del = True
        else:
            chat.to_del = True
        db.session.commit()  # Commit the session once
        #return response('Success! Chat Removed For You')
        if connection_manager.is_connected(data.to or request.sid):
            """update payload if .to is online/connected"""
            data['online'] = True 
    data['error'] = True 
    connection_manager.notify(data.to, json.dumps(data))


@socketio.on('update-chat')
def update(data):
    if data.id is None:
        return bad_request('chat id is missing in the request data')
    chat = Chat.query.get(data.id)
    if chat is None:
        return bad_request('chat not found')
    
    if not (chat.fro == current_user.id):
        return bad_request(message="invalid request, it's not ur chat")
    
    chat.from_dict(data, new_chat=False)
    db.session.commit()

    data = chat.to_dict()
    data['success'] = True
    if connection_manager.is_connected(data.to or request.sid):
        """update payload if .to is online/connected"""
        data['online'] = True 
    connection_manager.notify(data.to, json.dumps(data))

""" class ConnectionManager_:
    def __init__(self):
        self.active_connections = {}

    def connect(self, socket):
        # inform * when a client connects
        id = str(uuid.uuid4())
        self.active_connections[id] = socket
        self.send_message_to(socket, json.dumps({"type": "connect", "id": id}))

    def disconnect(self, socket):
        id = self.find_connection_id(socket)
        del self.active_connections[id]
        return id

    def find_connection_id(self, socket):
        #find a specific connected user by connection-id
        return next((id for id, s in self.active_connections.items() if s == socket), None)

    def send_message_to(self, socket, message):
        #send to specify users connected 
        print(socket)
        socket.emit('message', message)

    def broadcast(self, message):
        #sending to all connected clients/users 
        for connection in self.active_connections.values():
            self.send_message_to(connection, message)

connection_manager = ConnectionManager()
 """
@chat_api.route('/chat', methods=['POST'])
def save_chat():
    data = request.get_json() or {}
    fro = data.get('fro')
    to = data.get('to')

    if not (['fro','to'] and ('text' or 'sticker' or 'media') ) in data:
        return bad_request('Can Not Send Blank Chats')

    if not User.user_exists(fro) and not User.user_exists(to):
        return bad_request('Invalid User Id(s)')
    
    chat = Chat()
    chat.from_dict(data, new_chat=True)
    db.session.add(chat)
    db.session.commit()
    response = jsonify(chat.to_dict())
    response.status_code = 201
    response.headers['Location'] = url_for('chat_api.get_chat', id=chat.id)
    return response


""" @socketio.on('connect')
def handle_connect():
    connection_manager.connect(request.sid)
    #connect = connection_manager.connect(request.sid)
    print(f"User {'handle_connect'} Connected")

@socketio.on('disconnect')
def handle_disconnect():
    id = connection_manager.disconnect(request.sid)
    print(f"User {id} Disconnected")

@socketio.on('message')
def handle_message(data):
    id = connection_manager.find_connection_id(request.sid)
    print(f"Received message from User {id}: {data}")
    connection_manager.send_message_to(data)

@socketio.on('message_all')
def handle_message(data):
    id = connection_manager.find_connection_id(request.sid)
    print(f"Received message from User {id}: {data}")
    connection_manager.broadcast(data) """

#here, id is user_id
""" @chat_api.route('/chat/<int:user_id>', methods=['GET'])
#@token_auth.login_required
def get_chat(user_id):
    if current_user.is_authenticated and not (user_id == current_user.id):
        return bad_request(message="Invalid Request. This is Not Ur Chat.")
        #pass
    chat = Chat.query.filter(or_(Chat.to == user_id, Chat.fro == user_id)).order_by(Chat.updated.desc()).all()
    page = request.args.get('page', 1, type=int)
    per_page = min(request.args.get('per_page', 10, type=int), 100)
    data = Chat.to_dict(chat, page, per_page, 'chat_api.get_chat')
    return jsonify(data) """

@chat_api.route('/chat/<int:id>', methods=['GET'])
#@token_auth.login_required
def get_chat(id):
    if current_user.is_authenticated and not (id == current_user.id):
        return bad_request(message="Invalid Request. This is Not Ur Chat.")
    chat = Chat.query.filter(or_(Chat.to == id, Chat.fro == id)).order_by(Chat.updated.desc())
    page = request.args.get('page', 1, type=int)
    per_page = min(request.args.get('per_page', 10, type=int), 100)
    data = Chat.to_collection_dict(chat, page, per_page, 'chat_api.get_chat', id=id)
    return jsonify(data)
  
@chat_api.route('/chat', methods=['PUT'])
def update_chat():
    data = request.get_json() or {}
    chat_id = data.get('id')  # Assuming you send the chat ID in the JSON data
    if chat_id is None:
        return bad_request('Chat-id is missing in the request data')
    chat = Chat.query.get(chat_id)
    if chat is None:
        return bad_request('Chat not found')
    
    if not (chat.fro == current_user.id):
        return bad_request(message="Invalid Request. This is Not Ur Chat.")
    
    chat.from_dict(data, new_chat=False)
    db.session.commit()
    return jsonify(chat.to_dict())

@chat_api.route('/chat/<int:id>', methods=['DELETE'])
#@token_auth.login_required
def remove_chat(id):  # Use 'id' as the parameter name
    chat = Chat.query.get(id)  # Replace 'chat_id' with 'id'
    if chat:
        if not (chat.fro == current_user.id or chat.to == current_user.id):
            return bad_request(message="Invalid Request. This is Not Ur Chat.")
        if chat.fro == current_user.id:
            chat.fro_del = True
        else:
            chat.to_del = True
        db.session.commit()  # Commit the session once
        return response('Success! Chat Removed For You')
    return bad_request('Oops! Invalid Chat Request')

